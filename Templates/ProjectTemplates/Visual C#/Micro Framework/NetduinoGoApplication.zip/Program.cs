﻿using System;
using System.Threading;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;
using SecretLabs.NETMF.Hardware;
using SecretLabs.NETMF.Hardware.NetduinoGo;

namespace $safeprojectname$
{
    public class Program
    {
        public static void Main()
        {
            // write your code here


        }

    }
}
